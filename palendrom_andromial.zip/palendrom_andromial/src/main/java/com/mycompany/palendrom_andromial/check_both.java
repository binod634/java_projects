/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.palendrom_andromial;

/**
 *
 * @author annomy
 */
import java.util.Scanner;   // importing library of Scanner to get imput

class news {

    int a, b, c = 0, e;                  // Declaring variable to use in fulture

    /* Defination of function to check if the number is andromial or not */
    public String andro(int a) {
        e = a;
        while (a != 0) {
            b = a % 10;
            c = c + b ^ 2;
            a = a / 10;
        }
        if (e == c) {
            return ("!!! THE NUMBER IS ANDROMIAL !!!");
        } else {
            return ("!!! THE NUMBER IS NOT ANDROMIAL !!!");
        }
    }

    /* FUNCTION TO CHECK IF NUMBER IS PALENDROMIAL */
    public String pal(int a) {
        e = a;
        c = 0;
        while (a != 0) {              // LOGIC
            b = a % 10;
            c = c * 10 + b;
            a = a / 10;
        }
        if (e == c) {
            return ("### THE NUMBER IS A PALENDROMIAL ###");             // return with message
        } else {
            return ("### THE NUMBER IS NOT PALENDROMIAL ###");           // return with message
        }
    }
}


/* BEGAIN CLASS DEFINATION */
public class check_both {

    /* BEGAIN MAIN FUNCTION */
    int d;

    public static void main(String args[]) {
        System.out.println("Enter a number to check: ");                // Asking Input from user
        Scanner ob = new Scanner(System.in);
        int d = ob.nextInt();
        news obj = new news();
        System.out.println(obj.pal(d));
        System.out.println(obj.andro(d));
    }
}
