/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;
/**
 *
 * @author annomy
 */
public class bk1 {
    public static void main(String args[]) {
        System.out.println("This is from file bk1.java...");
        r ob=new r();
        System.out.println(ob.call());
    }
}
