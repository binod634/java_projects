/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.interface_test;

/**
 *
 * @author annomy
 */

interface bk {
    String a="HELLO WORLD !!!";
    String test();
}

class test implements bk {
    public String  test() {
        return(a);
    }
}

public class new1 {
    public static void main(String args[]) {
        test ob=new test();
        System.out.println(ob.test());
    }
}
