/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.multiple_println;

/**
 *
 * @author annomy
 */
public class test {
    public static void main(String args[]) {    // main function
        System.out.print("HELLO ");            // first word printing
        System.out.print("World !!");
    }
    
}

/* THIS IS JUST FOR TESTING MULTIPLE LINE COMMENTS */

/* END OF PROGRAMMING BY [ANNOMY] */